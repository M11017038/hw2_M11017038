#------------------函式庫------------------
from adult_uci_info import Adult
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error
from math import sqrt
import numpy as np

#------------------Function------------------
def mape(test_y,y_pre):
    return np.mean(np.abs((y_pre-test_y)/test_y))*100

#------------------Code Section------------------
uci=Adult()
train_x, train_y, test_x, test_y=uci()
svr=SVR(kernel="rbf")
svr.fit(train_x, train_y)
y_pre=svr.predict(test_x)

#------------------Print Section------------------
print("\nAdult_DataSet\n")
print("--------SVR Method--------")
print("RMSE: "+str(sqrt(mean_squared_error(test_y,y_pre))))
print("MAE: "+str(mean_absolute_error(test_y,y_pre)))
print("MAPE: "+str(mape(test_y,y_pre)))
print("-----------End------------")
