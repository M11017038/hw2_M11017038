#------------------函式庫------------------
import numpy as np
from Online_shoppers_intention import online_shoppers_intention
from sklearn.ensemble import RandomForestRegressor as RFR
from sklearn.metrics import mean_squared_error, mean_absolute_error
from math import sqrt

#------------------Function------------------
def mape(test_y,y_pre):
    return np.mean(np.abs((y_pre-test_y)/test_y))*100

#------------------Code Section------------------
uci=online_shoppers_intention()
train_x, train_y, test_x, test_y=uci()
rfr=RFR(n_estimators=30, max_depth=4, max_features=0.6, n_jobs=-1)
rfr.fit(train_x, train_y)
y_pre=rfr.predict(test_x)

#------------------Print Section------------------
print("\nonline_shoppers_intention_DataSet\n")
print("--------RandomForest Method--------")
print("RMSE: "+str(sqrt(mean_squared_error(test_y,y_pre))))
print("MAE: "+str(mean_absolute_error(test_y,y_pre)))
print("MAPE: "+str(mape(test_y,y_pre)))
print("----------------End----------------")