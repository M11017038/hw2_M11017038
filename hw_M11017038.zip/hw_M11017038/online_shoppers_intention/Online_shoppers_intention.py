import Loader_UCI

class online_shoppers_intention():
    def __init__(self):
        self.names = ['Administrative','Administrative_Duration','Informational','Informational_Duration','ProductRelated','ProductRelated_Duration','BounceRates','ExitRates','PageValues','SpecialDay']
        self.drop = []
        self.encode_tag = []
        self.label_tag = 'ExitRates'
        self.normalize_tag = ['Administrative','Administrative_Duration','Informational','Informational_Duration','ProductRelated','ProductRelated_Duration','BounceRates','PageValues','SpecialDay']
    def load(self):
        uci = Loader_UCI.Loader("", self.names, self.label_tag, drop_tags=self.drop, 
                encode_tags=self.encode_tag, normal_tags=self.normalize_tag)
        return uci()
    def __call__(self):
        return self.load()