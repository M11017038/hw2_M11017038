#------------------函式庫------------------
from sklearn.neighbors import KNeighborsClassifier
from Online_shoppers_intention import online_shoppers_intention
from sklearn.metrics import mean_squared_error, mean_absolute_error
from math import sqrt
import numpy as np

#------------------Function------------------
def mape(test_y,y_pre):
    return np.mean(np.abs((y_pre-test_y)/test_y))*100

#------------------Code Section------------------
uci=online_shoppers_intention()
train_x, train_y, test_x, test_y=uci()
clf=KNeighborsClassifier(n_neighbors=20,p=2,weights='distance',algorithm='brute')
clf.fit(train_x,train_y)
y_pre=clf.predict(test_x)
clf.score(test_x,test_y)

#------------------Print Section------------------
print("\nonline_shoppers_intention_DataSet\n")
print("--------KNN Method--------")
print("K_Value: 20")
print("RMSE: "+str(sqrt(mean_squared_error(test_y,y_pre))))
print("MAE: "+str(mean_absolute_error(test_y,y_pre)))
print("MAPE :"+str(mape(test_y,y_pre)))
print("-----------End------------")